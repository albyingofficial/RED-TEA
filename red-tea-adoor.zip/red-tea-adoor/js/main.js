(function(){
  "use strict";
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var hasGsap = typeof window.gsap !== "undefined" && typeof window.ScrollTrigger !== "undefined";
  if(!hasGsap || reduce) document.documentElement.classList.add("no-anim");

  /* ---------------- MENU DATA ---------------- */
  var MENU = {
    kerala:[
      {id:"kappa-biriyani",name:"Kappa Biriyani",ml:"കപ്പ ബിരിയാണി",desc:"Mashed tapioca cooked down with spiced meat. Hearty, peppery and very Kerala.",tags:["sig"]},
      {id:"puttu-kadala",name:"Puttu & Kadala",ml:"പുട്ടും കടലയും",desc:"Steamed rice and coconut puttu with black chickpea curry.",tags:["veg"]},
      {id:"beef-fry",name:"Beef Fry",ml:"ബീഫ് ഫ്രൈ",desc:"Local-style, slow roasted with coconut slivers, curry leaves and pepper.",tags:["sig","spicy"]},
      {id:"chicken-biriyani",name:"Chicken Biriyani",ml:"ചിക്കൻ ബിരിയാണി",desc:"Kerala-style biriyani with fried onions, raita and pickle.",tags:[]},
      {id:"porotta",name:"Porotta",ml:"പൊറോട്ട",desc:"Flaky layered flatbread. The partner for any fry or curry.",tags:["veg"]},
      {id:"chicken-curry",name:"Nadan Chicken Curry",ml:"നാടൻ ചിക്കൻ കറി",desc:"Home-style curry with roasted coconut and whole spices.",tags:["spicy"]}
    ],
    wok:[
      {id:"chilli-chicken",name:"Chilli Chicken",desc:"Crisp chicken tossed with capsicum, onion and green chilli.",tags:["spicy"]},
      {id:"fried-rice",name:"Chicken Fried Rice",desc:"Wok-tossed rice with egg, spring onion and pepper.",tags:[]},
      {id:"schezwan-noodles",name:"Schezwan Noodles",desc:"Hakka noodles in a hot garlic-chilli Schezwan sauce.",tags:["spicy"]},
      {id:"gobi-manchurian",name:"Gobi Manchurian",desc:"Cauliflower fritters in a sticky soy-garlic glaze.",tags:["veg"]},
      {id:"dragon-chicken",name:"Dragon Chicken",desc:"Cashew, red chilli and sweet heat, straight off the flame.",tags:["spicy"]},
      {id:"veg-fried-rice",name:"Veg Fried Rice",desc:"Light and quick, good alongside any Kerala fry.",tags:["veg"]}
    ],
    chaya:[
      {id:"biriyani-chaya",name:"Biriyani Chaya",ml:"ബിരിയാണി ചായ",desc:"The house combo: biriyani with a glass of hot chaya.",tags:["sig"]},
      {id:"chaya",name:"Chaya",ml:"ചായ",desc:"Strong, milky, pulled tea served in a glass.",tags:["veg"]},
      {id:"sulaimani",name:"Sulaimani",ml:"സുലൈമാനി",desc:"Black tea with lemon and a hint of spice. Good after biriyani.",tags:["veg"]},
      {id:"lime-soda",name:"Fresh Lime Soda",desc:"Sweet, salt or mixed. Ice cold.",tags:["veg"]},
      {id:"kulukki",name:"Kulukki Sarbath",ml:"കുലുക്കി സർബത്ത്",desc:"Shaken lime, basil seeds and green chilli.",tags:["veg"]},
      {id:"coffee",name:"Hot Coffee",desc:"For the late crowd.",tags:["veg"]}
    ]
  };
  var BY_ID = {};
  Object.keys(MENU).forEach(function(k){MENU[k].forEach(function(d){BY_ID[d.id]=d;});});
  var TAG_LABEL = {sig:"Signature",veg:"Veg",spicy:"Spicy"};

  /* ---------------- TABLE LIST STATE ---------------- */
  var KEY = "redtea-table-v1";
  var cart = {};
  try{ var raw = localStorage.getItem(KEY); if(raw){ cart = JSON.parse(raw) || {}; } }catch(e){ cart = {}; }
  Object.keys(cart).forEach(function(id){ if(!BY_ID[id] || !(cart[id]>0)) delete cart[id]; });
  function save(){ try{ localStorage.setItem(KEY, JSON.stringify(cart)); }catch(e){} }
  function count(){ return Object.keys(cart).reduce(function(s,k){return s+cart[k];},0); }

  var dishesEl = document.getElementById("dishes");
  var current = "kerala";

  function esc(s){ return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];}); }
  function addLabel(id){ return cart[id] ? "Added · "+cart[id] : "Add to table"; }
  var plus = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M8 3v10M3 8h10"/></svg>';

  function renderDishes(animate){
    dishesEl.setAttribute("aria-labelledby","tab-"+current);
    dishesEl.innerHTML = MENU[current].map(function(d){
      var tags = d.tags.map(function(t){return '<span class="tag '+t+'">'+TAG_LABEL[t]+'</span>';}).join("");
      return '<article class="dish">'+
        '<h3>'+esc(d.name)+(d.ml?' <span class="ml" lang="ml">'+d.ml+'</span>':'')+'</h3>'+
        '<p>'+esc(d.desc)+'</p>'+
        (tags?'<div class="tags">'+tags+'</div>':'')+
        '<button class="add'+(cart[d.id]?' added':'')+'" type="button" data-add="'+d.id+'" aria-label="Add '+esc(d.name)+' to table list">'+plus+'<span>'+addLabel(d.id)+'</span></button>'+
      '</article>';
    }).join("");
    if(animate && hasGsap && !reduce){
      gsap.from(dishesEl.children,{y:24,opacity:0,duration:.5,stagger:.05,ease:"power2.out",clearProps:"all"});
    }
  }
  renderDishes(false);

  var tabs = Array.prototype.slice.call(document.querySelectorAll(".tab"));
  tabs.forEach(function(t,i){
    t.addEventListener("click",function(){ selectTab(t); });
    t.addEventListener("keydown",function(e){
      if(e.key==="ArrowRight"||e.key==="ArrowLeft"){
        e.preventDefault();
        var n = tabs[(i+(e.key==="ArrowRight"?1:-1)+tabs.length)%tabs.length];
        n.focus(); selectTab(n);
      }
    });
    t.tabIndex = t.getAttribute("aria-selected")==="true"?0:-1;
  });
  function selectTab(t){
    if(t.dataset.cat===current) return;
    tabs.forEach(function(x){ var on = x===t; x.setAttribute("aria-selected",on); x.tabIndex = on?0:-1; });
    current = t.dataset.cat;
    renderDishes(true);
    if(hasGsap) ScrollTrigger.refresh();
  }

  /* add buttons (menu + signature band) */
  document.addEventListener("click",function(e){
    var b = e.target.closest("[data-add]");
    if(!b) return;
    var id = b.getAttribute("data-add");
    cart[id] = (cart[id]||0)+1;
    save(); syncAll();
    toast(BY_ID[id].name+" added to your table");
    trayBtn.classList.remove("bump"); void trayBtn.offsetWidth; trayBtn.classList.add("bump");
  });

  /* ---------------- TRAY ---------------- */
  var trayBtn = document.getElementById("trayBtn"),
      tray = document.getElementById("tray"),
      scrim = document.getElementById("scrim"),
      list = document.getElementById("trayList"),
      empty = document.getElementById("trayEmpty"),
      cnt = document.getElementById("trayCount"),
      fallback = document.getElementById("copyFallback");
  var lastFocus = null;

  function syncAll(){
    var n = count();
    cnt.textContent = n;
    trayBtn.classList.toggle("show", n>0);
    // update add buttons in place
    document.querySelectorAll(".add[data-add]").forEach(function(b){
      var id = b.getAttribute("data-add");
      b.classList.toggle("added", !!cart[id]);
      var s = b.querySelector("span"); if(s) s.textContent = addLabel(id);
    });
    var ids = Object.keys(cart);
    empty.hidden = ids.length>0;
    list.innerHTML = ids.map(function(id){
      var d = BY_ID[id];
      return '<li><span class="nm">'+esc(d.name)+(d.ml?'<small lang="ml" class="ml">'+d.ml+'</small>':'')+'</span>'+
        '<span class="qty"><button type="button" data-dec="'+id+'" aria-label="One less '+esc(d.name)+'">−</button>'+
        '<output aria-live="polite">'+cart[id]+'</output>'+
        '<button type="button" data-inc="'+id+'" aria-label="One more '+esc(d.name)+'">+</button></span></li>';
    }).join("");
    document.getElementById("copyList").disabled = ids.length===0;
    fallback.hidden = true;
  }
  list.addEventListener("click",function(e){
    var inc = e.target.closest("[data-inc]"), dec = e.target.closest("[data-dec]");
    if(inc){ cart[inc.dataset.inc]++; }
    else if(dec){ var id = dec.dataset.dec; cart[id]--; if(cart[id]<=0) delete cart[id]; }
    else return;
    save(); syncAll();
  });
  function openTray(){
    lastFocus = document.activeElement;
    tray.classList.add("open"); scrim.classList.add("open");
    tray.setAttribute("aria-hidden","false");
    document.getElementById("trayClose").focus();
  }
  function closeTray(){
    tray.classList.remove("open"); scrim.classList.remove("open");
    tray.setAttribute("aria-hidden","true");
    if(lastFocus && lastFocus.focus) lastFocus.focus();
  }
  trayBtn.addEventListener("click",openTray);
  document.getElementById("openTray2").addEventListener("click",openTray);
  document.getElementById("trayClose").addEventListener("click",closeTray);
  scrim.addEventListener("click",closeTray);
  document.addEventListener("keydown",function(e){ if(e.key==="Escape" && tray.classList.contains("open")) closeTray(); });
  document.getElementById("clearList").addEventListener("click",function(){
    cart = {}; save(); syncAll(); toast("Table list cleared");
  });
  function listText(){
    var lines = Object.keys(cart).map(function(id){ return cart[id]+" × "+BY_ID[id].name; });
    return "Red Tea, Adoor Bypass · our table\n"+lines.join("\n");
  }
  document.getElementById("copyList").addEventListener("click",function(){
    var txt = listText();
    function showFallback(){
      fallback.value = txt; fallback.hidden = false; fallback.focus(); fallback.select();
      toast("Select the text and copy it");
    }
    try{
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(txt).then(function(){ toast("Table list copied"); }, showFallback);
      } else showFallback();
    }catch(err){ showFallback(); }
  });

  var toastEl = document.getElementById("toast"), tt;
  function toast(msg){
    toastEl.textContent = msg; toastEl.classList.add("show");
    clearTimeout(tt); tt = setTimeout(function(){ toastEl.classList.remove("show"); },1900);
  }
  syncAll();

  /* ---------------- NAV ---------------- */
  var nav = document.getElementById("nav"), lastY = window.scrollY;
  var toggle = document.getElementById("navToggle"), links = document.getElementById("navLinks");
  window.addEventListener("scroll",function(){
    var y = window.scrollY;
    nav.classList.toggle("solid", y>40);
    if(!links.classList.contains("open")) nav.classList.toggle("hide", y>lastY && y>400);
    lastY = y;
  },{passive:true});
  toggle.addEventListener("click",function(){
    var open = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded",open);
    toggle.setAttribute("aria-label",open?"Close menu":"Open menu");
    nav.classList.add("solid");
  });
  links.addEventListener("click",function(e){
    if(e.target.closest("a") && links.classList.contains("open")){ links.classList.remove("open"); toggle.setAttribute("aria-expanded","false"); }
  });
  /* active link */
  var sections = ["yard","menu","nights","visit"].map(function(id){return document.getElementById(id);});
  if("IntersectionObserver" in window){
    var io = new IntersectionObserver(function(ents){
      ents.forEach(function(en){
        if(en.isIntersecting){
          links.querySelectorAll("a[href^='#']").forEach(function(a){ a.classList.toggle("on", a.getAttribute("href")==="#"+en.target.id); });
        }
      });
    },{rootMargin:"-45% 0px -50% 0px"});
    sections.forEach(function(s){ io.observe(s); });
  }

  /* ---------------- STRING LIGHTS CANVAS ---------------- */
  var cv = document.getElementById("lights"), ctx = cv.getContext("2d");
  var W=0,H=0,DPR=1,strands=[],start=performance.now(),running=true,mx=0;
  function buildStrands(){
    DPR = Math.min(window.devicePixelRatio||1,2);
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = W*DPR; cv.height = H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0);
    var defs = W<700
      ? [{y0:.14,y1:.08,sag:.30},{y0:.04,y1:.22,sag:.34}]
      : [{y0:.16,y1:.06,sag:.34},{y0:.02,y1:.20,sag:.40},{y0:.10,y1:.12,sag:.52}];
    var gap = W<700?26:34, idx=0;
    strands = defs.map(function(d,si){
      var bulbs=[], n=Math.max(8,Math.round(W/gap));
      for(var i=0;i<=n;i++){
        var t=i/n;
        bulbs.push({t:t, phase:Math.random()*6.28, speed:.6+Math.random()*1.2, delay:(t*0.9)+si*.22, r:W<700?2.1:2.6});
        idx++;
      }
      return {d:d,bulbs:bulbs};
    });
  }
  function pt(s,t,sway){
    var x = t*W;
    var y = (s.d.y0 + (s.d.y1-s.d.y0)*t)*H + Math.sin(Math.PI*t)*s.d.sag*H;
    return [x + sway*Math.sin(Math.PI*t), y];
  }
  function draw(now){
    if(!running) return;
    var el = (now-start)/1000;
    ctx.clearRect(0,0,W,H);
    strands.forEach(function(s,si){
      var sway = (reduce?0:Math.sin(el*.6+si)*3) + mx*(6+si*3);
      ctx.beginPath();
      for(var i=0;i<=60;i++){ var p=pt(s,i/60,sway); if(i===0)ctx.moveTo(p[0],p[1]); else ctx.lineTo(p[0],p[1]); }
      ctx.strokeStyle="rgba(20,22,18,.85)"; ctx.lineWidth=1.4; ctx.stroke();
      s.bulbs.forEach(function(b){
        var p = pt(s,b.t,sway);
        var on = reduce?1:Math.min(1,Math.max(0,(el-b.delay)/.25));
        var tw = reduce?1:(.78+.22*Math.sin(el*b.speed*2+b.phase));
        var a = on*tw;
        if(a<=0.01){ ctx.fillStyle="rgba(120,100,60,.5)"; ctx.beginPath(); ctx.arc(p[0],p[1]+3,b.r*.8,0,6.28); ctx.fill(); return; }
        var g = ctx.createRadialGradient(p[0],p[1]+3,0,p[0],p[1]+3,b.r*7);
        g.addColorStop(0,"rgba(255,226,160,"+(.55*a)+")");
        g.addColorStop(1,"rgba(255,200,110,0)");
        ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p[0],p[1]+3,b.r*7,0,6.28); ctx.fill();
        ctx.fillStyle="rgba(255,240,205,"+(.35+.65*a)+")";
        ctx.beginPath(); ctx.arc(p[0],p[1]+3,b.r,0,6.28); ctx.fill();
      });
    });
    if(!reduce || el<.1) requestAnimationFrame(draw);
  }
  buildStrands(); requestAnimationFrame(draw);
  var rT; window.addEventListener("resize",function(){ clearTimeout(rT); rT=setTimeout(buildStrands,150); });
  window.addEventListener("pointermove",function(e){ mx = (e.clientX/window.innerWidth-.5); },{passive:true});
  if("IntersectionObserver" in window && !reduce){
    new IntersectionObserver(function(es){
      var vis = es[0].isIntersecting;
      if(vis && !running){ running=true; requestAnimationFrame(draw); }
      running = vis;
    }).observe(document.getElementById("hero"));
  }

  /* ---------------- GSAP SCROLL ---------------- */
  if(!hasGsap || reduce){
    document.querySelectorAll(".board").forEach(function(b){ b.classList.add("lit"); });
    return;
  }
  gsap.registerPlugin(ScrollTrigger);

  // hero intro
  var intro = gsap.timeline({defaults:{ease:"power4.out"}});
  intro.from("#heroImg",{opacity:0,duration:1.2,ease:"power2.out"},0)
       .from(".hero h1 .line>span",{yPercent:110,duration:1.1,stagger:.12},.25)
       .from("[data-hero]",{y:24,opacity:0,duration:.9,stagger:.1},.55);

  // hero scroll parallax
  gsap.to(".hero-copy",{y:-80,opacity:.15,ease:"none",scrollTrigger:{trigger:"#hero",start:"35% top",end:"bottom top",scrub:true}});

  // marquee, speed tied to scroll velocity
  function loop(sel,dir){
    var tw = gsap.fromTo(sel,{xPercent:dir>0?0:-50},{xPercent:dir>0?-50:0,duration:28,ease:"none",repeat:-1});
    return tw;
  }
  var mA = loop("#mqA",1), mB = loop("#mqB",-1);
  ScrollTrigger.create({trigger:".marquee",start:"top bottom",end:"bottom top",onUpdate:function(self){
    var v = Math.min(5,1+Math.abs(self.getVelocity())/350);
    gsap.to([mA,mB],{timeScale:v*(self.direction||1),duration:.25,overwrite:true});
    gsap.to([mA,mB],{timeScale:self.direction||1,duration:1.2,delay:.25});
  }});

  // generic reveals
  gsap.utils.toArray("[data-reveal]").forEach(function(el){
    gsap.from(el,{y:56,opacity:0,duration:1,ease:"power3.out",scrollTrigger:{trigger:el,start:"top 88%",once:true}});
  });

  // menu rows on first view
  ScrollTrigger.create({trigger:"#dishes",start:"top 85%",once:true,onEnter:function(){
    gsap.from("#dishes .dish",{y:30,opacity:0,duration:.7,stagger:.07,ease:"power3.out",clearProps:"all"});
  }});

  var mm = gsap.matchMedia();

  // yard: clip-path reveal + beats
  mm.add("(min-width: 861px)",function(){
    gsap.fromTo("#yardFrame",{clipPath:"inset(14% 12% 14% 12% round 24px)"},{clipPath:"inset(0% 0% 0% 0% round 6px)",ease:"none",
      scrollTrigger:{trigger:"#yard",start:"top 75%",end:"top 5%",scrub:true}});
    gsap.fromTo("#yardImg",{yPercent:-8},{yPercent:0,ease:"none",scrollTrigger:{trigger:"#yard",start:"top bottom",end:"bottom top",scrub:true}});
    var beats = gsap.utils.toArray("[data-beat]");
    beats.forEach(function(b){
      ScrollTrigger.create({trigger:b,start:"top 60%",end:"bottom 40%",onToggle:function(s){ if(s.isActive){ beats.forEach(function(x){x.classList.toggle("on",x===b);}); } }});
    });
  });
  mm.add("(max-width: 860px)",function(){
    gsap.fromTo("#yardFrame",{clipPath:"inset(8% 8% 8% 8% round 18px)"},{clipPath:"inset(0% 0% 0% 0% round 6px)",ease:"none",
      scrollTrigger:{trigger:"#yardFrame",start:"top 95%",end:"top 35%",scrub:true}});
  });

  // nights: horizontal pinned scroll on desktop
  mm.add("(min-width: 900px)",function(){
    var track = document.getElementById("track");
    function dist(){ return Math.max(0, track.scrollWidth - window.innerWidth); }
    var tw = gsap.to(track,{x:function(){return -dist();},ease:"none",
      scrollTrigger:{trigger:"#nights",start:"top top",end:function(){return "+="+dist();},pin:true,scrub:.8,invalidateOnRefresh:true,anticipatePin:1}});
    gsap.utils.toArray("#track .panel:not(.photo)").forEach(function(p){
      gsap.from(p.querySelector(".icon"),{rotate:-25,scale:.6,opacity:0,duration:.8,ease:"back.out(2)",
        scrollTrigger:{trigger:p,containerAnimation:tw,start:"left 85%",once:true}});
    });
    gsap.fromTo("#track .panel.photo img",{scale:1.15},{scale:1,ease:"none",scrollTrigger:{trigger:"#nights",start:"top bottom",end:"top top",scrub:true}});
  });
  mm.add("(max-width: 899px)",function(){
    gsap.utils.toArray("#track .panel").forEach(function(p){
      gsap.from(p,{y:50,opacity:0,duration:.8,ease:"power3.out",scrollTrigger:{trigger:p,start:"top 90%",once:true}});
    });
  });

  // sign boards light up one by one
  var boards = gsap.utils.toArray(".board");
  ScrollTrigger.create({trigger:"#boards",start:"top 80%",once:true,onEnter:function(){
    boards.forEach(function(b,i){ setTimeout(function(){ b.classList.add("lit"); }, 160*i + (i===0?0:200)); });
  }});
  gsap.fromTo("#signImg",{yPercent:-6,scale:1.1},{yPercent:6,scale:1.1,ease:"none",scrollTrigger:{trigger:"#compound",start:"top bottom",end:"bottom top",scrub:true}});

  window.addEventListener("load",function(){ ScrollTrigger.refresh(); });
})();
