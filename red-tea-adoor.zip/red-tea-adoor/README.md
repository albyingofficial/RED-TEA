# Red Tea Adoor

Website for Red Tea Restaurant, Adoor Bypass Road, Kerala.
Plain HTML, CSS and JavaScript. No build step and no install needed.

## Files

```
index.html        page markup
css/style.css     all styles
js/main.js        menu, table list, string lights, scroll animations (GSAP)
images/           restaurant photos
favicon.svg       browser tab icon
vercel.json       Vercel settings (image caching)
```

GSAP and Google Fonts load from their CDNs, so the page needs an internet connection for animations and fonts.

## Run it locally

Open `index.html` in a browser, or run a small local server from this folder:

```
npx serve .
```

## Put it on GitHub

1. Create a new empty repository on github.com (for example `red-tea-adoor`).
2. In this folder run:

```
git init
git add .
git commit -m "Red Tea website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/red-tea-adoor.git
git push -u origin main
```

Or drag all files and folders into the repo page with **Add file → Upload files**.

## Deploy on Vercel

1. Go to vercel.com and sign in with GitHub.
2. Click **Add New → Project** and import the `red-tea-adoor` repository.
3. Leave Framework Preset as **Other**. Leave Build Command and Output Directory empty.
4. Click **Deploy**.

Every push to `main` redeploys the site automatically.
